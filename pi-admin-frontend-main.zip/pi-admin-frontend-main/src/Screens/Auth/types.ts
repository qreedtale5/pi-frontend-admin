export interface LoginFormValues {
    email: string;
    password: string;
    token?: string;
  }
